# SOLANA Scalp Strategy — Backtest Guide

Your strategy is designed to catch dips in the $80-85 SOLANA chop zone with 50% scalp + 50% swing.

To properly backtest this, you need **TradingView** — it's the industry standard for crypto backtesting.

---

## How to Backtest on TradingView (5 minutes)

1. **Open TradingView.com** (free account)
2. **Search for SOLUSDT** (Binance perpetual or spot)
3. **Click "Strategy Tester"** (top right of chart)
4. **Chart settings:**
   - Timeframe: **1H** (hourly — to catch dips)
   - Date range: **Last 15 days** (April 18 - May 3, 2026)

5. **Add your indicators** to the chart:
   - EMA(8) — blue line
   - EMA(21) — red line
   - RSI(14) — below chart
   - Bollinger Bands(20,2) — optional but helpful
   - Volume SMA(20) — below volume bars

6. **Manually backtest** (or create a Pine Script bot):
   - Look for candles where RSI < 40 during uptrends
   - Count how many would have triggered a "Buy" signal
   - Trace forward 2-3 candles: Did price hit +2% (win) or -1.5% (loss)?
   - Track the results

---

## What You'll Find (Estimated)

For SOLANA in past 15 days (April 18 - May 3):

**Typical Results for Hourly Scalping:**
- **Total signals:** 8-12 potential entries (rough estimate)
- **Win rate:** 60-70% (good scalping strategy)
- **Avg profit/win:** +2.2% (scalp exits at +2-3%)
- **Avg loss/loss:** -1.4% (stopped out at -1.5%)
- **Risk-reward ratio:** 1.5:1 (decent)

**Example backtest on SOLUSDT 1H (hypothetical):**
- Apr 20 10:00 — RSI < 40, EMA8 > EMA21 → BUY → +2.1% ✓ WIN
- Apr 20 15:00 — RSI > 70, EMA8 < EMA21 → SELL → -1.8% ✗ LOSS
- Apr 21 08:00 — RSI < 35, Volume spike → BUY → +2.8% ✓ WIN
- Apr 22 12:00 — RSI > 65 → SELL → +2.0% ✓ WIN
- ... (continuing)

---

## Why Hourly Matters for Your Strategy

**Crypto trades 24/7 (unlike NYSE 9:30-16:00 EDT):**

| Check Frequency | Dips Caught | Over-trading Risk | Best For |
|---|---|---|---|
| Daily | Low (miss intraday dips) | None | Swing trades |
| **Hourly** | **High (catch most dips)** | **Manageable** | **Scalping (YOUR STRATEGY)** |
| Every 15 min | Very high | High (whipsaws) | HFT / expert only |

**Your strategy + hourly checks = good match** ✓
- Catches the dips in the $80-85 chop zone
- Still respects the 2-trades/day limit (won't over-execute)
- Aligned with scalping goals

---

## Blockchain Backer's Approach

Blockchain Backer typically focuses on **daily/weekly swing trades** using:
- **Daily timeframe** for trend bias
- **4H chart** for entry confirmation
- **Volume + divergence** for confirmation

However, for **scalping a chop zone** (which is your specific goal), **hourly is standard practice**.

Blockchain Backer's philosophy: *"Use higher timeframes for direction, lower timeframes for entry."*

Your setup:
- **Higher TF (trend bias):** Daily timeframe (EMA21 = trend direction)
- **Lower TF (entries):** Hourly (RSI dips = entry trigger)

This matches his methodology.

---

## Action Items

### Step 1: Update your bot to hourly checks
```bash
# In .env, change:
TIMEFRAME=1D
# To:
TIMEFRAME=1H
```

### Step 2: Backtest manually on TradingView
1. Go to TradingView.com
2. Search SOLUSDT
3. Set to 1H timeframe
4. Look back 15 days
5. Add EMA(8), EMA(21), RSI(14)
6. Manually count wins/losses following your rules

### Step 3: Share your backtest results
Once you've done the manual backtest, let me know:
- How many entry signals triggered in 15 days?
- How many won? How many lost?
- What was the win rate?
- Any obvious failures or edge cases?

This will help refine the strategy before you go live.

---

## Pine Script Automation (Advanced)

If you want to fully automate the backtest, TradingView has **Pine Script** — you can code your exact strategy and backtest 5 years of data in seconds.

I can write the Pine Script for you if you want to go that route. It would:
1. Calculate EMA(8) and EMA(21)
2. Check RSI(14) conditions
3. Simulate entries/exits on historical data
4. Generate win/loss report with exact numbers

Let me know if you want me to write the Pine Script.

---

## Summary

**Your plan:**
- ✅ Change to **hourly checks** (catches dips, aligns with scalping)
- ✅ Backtest manually on TradingView for 15 days
- ✅ Count wins/losses to validate strategy
- ✅ Then deploy live with confidence

**Next message:** Tell me you want hourly, and I'll update the deployment schedule.
