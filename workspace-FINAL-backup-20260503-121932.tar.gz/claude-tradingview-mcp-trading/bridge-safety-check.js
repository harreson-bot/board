/**
 * Bridge Safety Check Module
 * 
 * Used by bot.js to verify live data before executing REAL trades
 * Prevents accidental trading with demo data when using real money
 * 
 * Usage:
 *   import { checkTradingSafe } from './bridge-safety-check.js'
 *   if (await checkTradingSafe('SOLUSDT')) {
 *     executeOrder(...)
 *   }
 */

export async function checkTradingSafe(symbol, bridgeUrl = 'http://localhost:3001') {
  try {
    const response = await fetch(`${bridgeUrl}/trading-safe/${symbol}`)
    const data = await response.json()
    
    return {
      isSafe: data.isSafeToTrade,
      symbol: data.symbol,
      liveMode: data.liveMode,
      checks: data.checks,
      details: data.details,
      timestamp: data.timestamp,
    }
  } catch (err) {
    console.error(`[SAFETY] Bridge unreachable: ${err.message}`)
    return {
      isSafe: false,
      error: `Bridge unreachable: ${err.message}`,
    }
  }
}

/**
 * Detailed safety check with logging
 * Use this before every real trade
 */
export async function validateBeforeTrade(symbol, bridgeUrl = 'http://localhost:3001') {
  console.log(`\n[SAFETY CHECK] Validating before trade: ${symbol}`)
  
  const safety = await checkTradingSafe(symbol, bridgeUrl)
  
  if (!safety.isSafe) {
    console.error('\n' + '='.repeat(80))
    console.error('[SAFETY] ❌ TRADE BLOCKED - NOT SAFE')
    console.error('='.repeat(80))
    console.error(`Symbol: ${symbol}`)
    console.error(`Reason: ${safety.error || 'Conditions not met'}`)
    
    if (safety.checks) {
      console.error('\nFailed checks:')
      Object.entries(safety.checks).forEach(([name, check]) => {
        if (!check.passed) {
          console.error(`  ❌ ${name}: ${check.message}`)
        }
      })
    }
    console.error('='.repeat(80) + '\n')
    return false
  }
  
  console.log('\n' + '='.repeat(80))
  console.log('[SAFETY] ✅ ALL CHECKS PASSED - SAFE TO TRADE')
  console.log('='.repeat(80))
  
  if (safety.checks) {
    console.log('\nPassed checks:')
    Object.entries(safety.checks).forEach(([name, check]) => {
      if (check.passed) {
        console.log(`  ✓ ${name}: ${check.message}`)
      }
    })
  }
  
  if (safety.details) {
    console.log(`\nData details:`)
    console.log(`  • Time since last update: ${safety.details.timeSinceLastUpdate}`)
    console.log(`  • Time since live data: ${safety.details.timeSinceLiveData}`)
    console.log(`  • Candles available: ${safety.details.candleCount}`)
    console.log(`  • TradingView connected: ${safety.details.tvConnected ? '✓' : '✗'}`)
    console.log(`  • Using live data: ${safety.details.isLiveData ? '✓' : '✗'}`)
  }
  
  console.log(`  • Timestamp: ${safety.timestamp}`)
  console.log('='.repeat(80) + '\n')
  
  return true
}

/**
 * Check bridge health
 */
export async function checkBridgeHealth(bridgeUrl = 'http://localhost:3001') {
  try {
    const response = await fetch(`${bridgeUrl}/health`)
    const data = await response.json()
    
    return {
      healthy: data.status === 'ok',
      status: data.status,
      tvConnected: data.tvConnected,
      symbols: data.symbols,
      dataPoints: data.dataPoints,
      timestamp: data.timestamp,
    }
  } catch (err) {
    return {
      healthy: false,
      error: err.message,
    }
  }
}

/**
 * Get safety warning history
 */
export async function getSafetyWarnings(bridgeUrl = 'http://localhost:3001') {
  try {
    const response = await fetch(`${bridgeUrl}/safety-warnings`)
    const data = await response.json()
    
    return {
      liveMode: data.liveMode,
      allowDemoData: data.allowDemoData,
      totalWarnings: data.totalWarnings,
      warnings: data.warnings || [],
      timestamp: data.timestamp,
    }
  } catch (err) {
    return {
      error: err.message,
    }
  }
}

export default {
  checkTradingSafe,
  validateBeforeTrade,
  checkBridgeHealth,
  getSafetyWarnings,
}
