# How to Add the Pine Script to TradingView

Your Pine Script is ready: `solana-scalp-strategy.pine`

This script will show:
- ✅ **Green triangles** = BUY signals (all conditions met)
- ❌ **Red triangles** = SELL signals (profit/stop/trend break)
- 📊 **Live table** = Real-time condition status

---

## Step-by-Step: Add Script to TradingView

### 1. Open TradingView Chart
- Search for **SOLUSDT** (1H timeframe)
- Make sure you have 15+ days of history visible

### 2. Access Pine Script Editor
- **Mac/Linux:** Click `{}` (code icon) top-left of chart
- **Windows:** Same location, or press `Alt+P`

### 3. Create New Script
- Click **"New"** (or `Ctrl+N`)
- A blank script editor opens

### 4. Copy & Paste the Code
- Open `solana-scalp-strategy.pine` from the workspace
- Copy ALL the code
- Paste into the TradingView Pine Script editor
- Click **"Save"** (give it a name like "SOLANA Scalp")

### 5. Add to Chart
- Click **"Add to Chart"** (or press `Ctrl+Enter`)
- The script compiles and displays on your chart

### 6. What You'll See
- **Blue line:** EMA(8) — fast momentum
- **Red line:** EMA(21) — trend direction
- **Gray lines:** Bollinger Bands (support/resistance)
- **Green triangles:** BUY signals appear below candles
- **Red triangles:** SELL signals appear above candles
- **Table (top-right):** Real-time condition checklist

---

## Real-Time Backtest: Manual Trading

Once the script is live on your chart:

### For Each Green Triangle (BUY Signal):
1. **Write down:** Date, time, price
2. **Trace forward 2-4 candles:**
   - Did price hit **+2%?** (WIN ✓)
   - Or hit **-1.5%?** (LOSS ✗)
3. **Record result**

### After 15 Days of Data:
- Count: # of buys, # of wins, # of losses
- Calculate: Win rate = (wins / total) × 100
- Share results with me for strategy fine-tuning

---

## What the Table Shows (Top-Right)

```
┌─────────────────┬──────────┐
│ SOLANA Scalp... │          │
├─────────────────┼──────────┤
│ Price > EMA21   │ ✓ Bull   │  ← Trend OK
│ EMA8 > EMA21    │ ✓ UP     │  ← Momentum OK
│ RSI < 40        │ ✓ < 40   │  ← Oversold OK
│ RSI > 45        │ ✓ > 45   │  ← Recovery OK (entry ready!)
│ Volume > MA     │ ✓ Above  │  ← Confirmed
│ BB Upper        │ ✓ Clear  │  ← Room to go up
├─────────────────┼──────────┤
│ Signal          │ 🟢 BUY   │  ← ALL CONDITIONS MET!
└─────────────────┴──────────┘
```

**When all conditions show ✓:** Green triangle appears on chart = BUY signal

---

## If Script Doesn't Compile

**Common issues:**

1. **Error: "Unknown variable"**
   - Make sure you copied the ENTIRE script (all 200+ lines)
   - Don't remove any lines

2. **Error: "Invalid syntax"**
   - Check that there are no extra spaces/tabs at the beginning of lines
   - Copy fresh from the .pine file

3. **Script added but no signals**
   - Make sure timeframe is **1H** (1-hour)
   - Make sure you have **15+ days** of price history visible
   - Zoom out to see more candles
   - Wait a few candles for RSI to establish patterns

4. **Table doesn't appear**
   - Table only shows on the LAST candle (current candle)
   - If it's hidden: right-click script name in Indicators → Show/Hide

---

## Script Parameters (Adjustable)

If you want to fine-tune the strategy, go to script settings:

1. Right-click chart → **"Script Settings"** (or click gear icon)
2. Adjust these:

| Parameter | Current | Adjust If |
|-----------|---------|-----------|
| EMA Fast | 8 | Too many signals? Try 9-10 |
| EMA Slow | 21 | Missed signals? Try 18-20 |
| RSI Length | 14 | Standard, don't change |
| RSI Oversold | 40 | More aggressive? Try 35 |
| RSI Recovery | 45 | More aggressive? Try 40 |
| Volume MA | 20 | Need more volume? Try 30 |
| Profit Target | 2.5% | More conservative? Try 3-4% |
| Stop Loss | 1.5% | Tighter risk? Try 1.2% |

---

## Compare Script Signals to Bot Signals

Your bot runs **every hour** and logs decisions to:
```
/home/dh_ygjkxx/trading-bot-solana/safety-check-log.json
```

**The Pine Script and bot use the SAME logic:**
- If script shows green triangle → bot will BUY (at the same time)
- If script shows red triangle → bot will SELL (at the same time)

You can verify they match by:
1. **At the top of each hour**, check:
   - TradingView chart: Does script show triangle?
   - Bot logs: Does `safety-check-log.json` show "TRADE EXECUTED"?
2. They should align perfectly (within seconds)

---

## Enable Alerts (Optional)

To get notifications when signals trigger:

1. In Pine Script editor, uncomment these lines (remove `//`):
```pine
// alertcondition(buy_signal, title="SOLANA Buy Signal", message="🟢 BUY: All conditions met!")
// alertcondition(sell_signal, title="SOLANA Sell Signal", message="🔴 SELL: Exit condition triggered")
```

2. Become:
```pine
alertcondition(buy_signal, title="SOLANA Buy Signal", message="🟢 BUY: All conditions met!")
alertcondition(sell_signal, title="SOLANA Sell Signal", message="🔴 SELL: Exit condition triggered")
```

3. Save and add to chart
4. Right-click chart → **"Manage Alerts"**
5. Set notification (email, SMS, app notification)

---

## Next Steps

1. **Add script to TradingView NOW**
2. **Watch 1-2 hours** — see if signals match bot activity
3. **Backtest manually** — count wins/losses over 15 days
4. **Share results** — I'll help optimize if needed
5. **Go live** — flip to real trading when confident

Your bot is running. The script will show you exactly what it sees.
