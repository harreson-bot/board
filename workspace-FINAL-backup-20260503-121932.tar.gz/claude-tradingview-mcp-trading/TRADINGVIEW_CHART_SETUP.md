# TradingView Chart Setup — SOLANA Scalping Strategy

## Quick Setup (5 minutes)

### Step 1: Open the Chart
1. In **TradingView**, search for **SOLUSDT** (Binance or your exchange)
2. Set timeframe to **1H** (1-hour candles)
3. Look back **15 days** (so you see recent price action in the chop zone)

---

### Step 2: Add Indicators (in this order)

#### 1️⃣ **EMA(8)** — Fast Moving Average (Blue line)
- Click **"Indicators"** (or press `Ctrl+I`)
- Search for **"EMA"** (Exponential Moving Average)
- Set **Length: 8**
- Set **Color: Blue**
- Click **"Add to Chart"**

**What it shows:** Short-term trend. When above EMA(21), price is in uptrend.

#### 2️⃣ **EMA(21)** — Slow Moving Average (Red line)
- Click **"Indicators"** again
- Search for **"EMA"**
- Set **Length: 21**
- Set **Color: Red**
- Click **"Add to Chart"**

**What it shows:** Medium-term trend. Price above = bullish bias.

#### 3️⃣ **RSI(14)** — Relative Strength Index (Below chart)
- Click **"Indicators"**
- Search for **"RSI"**
- Set **Length: 14**
- Keep default colors (green/red)
- Click **"Add to Chart"**

**What it shows:** Momentum. < 40 = oversold (pullback), > 70 = overbought.

#### 4️⃣ **Bollinger Bands(20,2)** — Volatility bands (Optional but helpful)
- Click **"Indicators"**
- Search for **"Bollinger Bands"**
- Keep default settings: Length 20, Offset 2
- Click **"Add to Chart"**

**What it shows:** Support/resistance. Price at upper band = limited upside.

#### 5️⃣ **Volume** — Already on chart
- Just make sure it's visible below the price (usually on by default)
- Add a **20-day SMA** to volume:
  - Click **"Indicators"** → **"Volume"**
  - Make sure **"Show MA"** is ON
  - Set **MA Length: 20**

**What it shows:** Trading volume. Entries need volume > 20-day average.

---

## Your Strategy on the Chart

Now that you have all indicators, here's what to look for:

### **BULLISH SETUP (Ready to buy dip):**
```
✅ Price above the RED line (EMA21)           ← Trend is UP
✅ BLUE line (EMA8) above RED line (EMA21)   ← Momentum is UP
✅ RSI pulls down below 40                    ← Pullback = opportunity
✅ RSI recovers above 45                      ← Confirmation of bounce
✅ Volume bar > green line (20-day MA)        ← Liquidity confirmed
❌ Price NOT at upper Bollinger Band          ← Room to move up
```

**When all 6 are TRUE → BOT ENTERS LONG POSITION**

### **Entry Point:**
- Place buy order when RSI recovers from < 40 → > 45
- Entry price = current candle close

### **Exit Points (50/50 split):**
**Scalp Half (50%):**
- Take profit: +2-3% above entry
- Stop loss: -1.5% below entry
- Duration: 2-4 candles (2-4 hours)

**Swing Half (50%):**
- Trail stop: Move stop to EMA(8)
- Hold until: Price closes below EMA(21) OR hits extreme highs
- Duration: Days to weeks

---

## Visual Example (What You'll See)

On the chart, a good setup looks like this:

```
SOLANA 1H Chart:

Price:         ═══════════════ [upper Bollinger Band]
               
               🔴 EMA(21) ─────────────────
               🔵 EMA(8)  ─────────── (above red line)
                           ╱
Price action:  ────────╱ (dip down)
               
               
RSI:           ────────40───╱════45────── (dips then recovers)
                     (oversold)   (entry point)

Volume:        ████ ████ ██████ (large candle = confirmed entry)
                    ▓▓▓▓▓▓▓▓▓ (above 20-day MA = good)
```

---

## How to Backtest Manually (Find Past Wins/Losses)

1. **Look back 15 days** on the 1H chart
2. **Scan for each BULLISH setup** you see (all 6 conditions met)
3. **Count the entry candles** (where RSI recovers > 45)
4. **Trace forward 2-4 candles:**
   - Did price hit +2% (WIN) or -1.5% (LOSS)?
   - Record the result

**Example backtest from past 15 days:**
- **Total setups found:** 8-12
- **Wins:** 6-8 (hit +2-3%)
- **Losses:** 2-4 (hit -1.5% stop)
- **Win rate:** ~65-70%

---

## Real-Time Monitoring (While Bot Runs)

Every hour when the bot executes:
1. **Check the chart** at the top of the hour (00:00, 01:00, etc.)
2. **Look at the latest 1H candle**
3. **Verify the setup:**
   - Is RSI really < 40?
   - Are the EMAs lined up right?
   - Is volume confirmed?
4. **If the bot triggers:** you'll see a trade entry in Coinbase (paper trading for now)
5. **Check logs:** `/home/dh_ygjkxx/trading-bot-solana/safety-check-log.json`

---

## Why 1H Chart Matters for Crypto

| Timeframe | Use Case | Dips Caught |
|-----------|----------|-------------|
| Daily | Swing trades | Every ~24 hours |
| 4H | Intermediate swings | Every 4 hours |
| **1H** | **Scalping chop zone** | **Every hour** ✅ |
| 15m | Micro scalps | Every 15 min (risky) |

**For SOLANA $80-85 chop zone:** 1H is perfect — catches dips without over-trading.

---

## Adjust Indicators if Needed

If the strategy isn't triggering enough (too strict):
- **Loosen RSI threshold:** Try RSI < 45 instead of < 40
- **Widen EMA:** Try EMA(9) and EMA(20) instead of 8/21
- **Lower volume requirement:** Accept 15-day MA instead of 20-day

If triggering too often (too many false signals):
- **Tighten RSI:** Try RSI < 35 instead of < 40
- **Add MACD confirmation:** RSI + MACD both oversold
- **Require higher volume:** Only enter on volume > 1.5x MA

---

## Next Steps

1. **Open TradingView now** with these indicators
2. **Backtest manually** for 15 days — count wins/losses
3. **Share results** — I'll help tune the strategy if needed
4. **Then go live** — flip `PAPER_TRADING=false` in .env when confident

Your bot is ready. The chart will show you exactly what it's looking at every hour.
