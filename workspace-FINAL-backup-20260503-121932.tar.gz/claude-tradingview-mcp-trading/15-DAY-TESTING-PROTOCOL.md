# 15-DAY TESTING PROTOCOL — SOLANA Trading Bot

**Status:** 🟢 **TESTING ACTIVE** (Started May 3, 2026)  
**Target Win Rate:** 60%+  
**Duration:** 15 days  
**Mode:** Paper Trading (no real money)  

---

## Overview

This document defines the 15-day testing protocol before going live with real money. The goal is to validate the SOLANA scalp strategy and confirm the 3-layer safety system works correctly.

## Daily Schedule

### 8:00 AM EDT — Automated Daily Report
**What:** Cron job automatically sends morning summary  
**Content:**
- Today's run count
- Win rate (today vs. overall)
- Safety blocks (if any)
- Progress toward 60% target
- Recommendation (continue testing or ready to go live)

**Command:** `node bot.js --test-report`  
**Output:** JSON summary from test-log.json + formatted metrics

### During Day — Hourly Bot Runs
**What:** Bot checks every hour for SOLANA dips in $80-85 chop zone  
**Triggers:** On the hour (0 * * * * cron)  
**Results:** Logged to test-log.json + trades.csv  

### Evening — Manual Review (Optional)
**What:** Spot-check logs for anomalies  
**Location:** `/home/dh_ygjkxx/trading-bot-solana/test-log.json`  
**Command:** `tail -50 test-log.json | jq '.runs[-10:]'`

---

## What's Being Tested

### 1. Strategy Performance
**Metric:** Win rate (target 60%+)  
**Entry Conditions (ALL must be true):**
- Price above EMA(21) — bullish bias
- EMA(8) above EMA(21) — short-term uptrend
- RSI < 40 — pullback in uptrend
- RSI recovers > 45 — momentum confirmation
- Volume > 20-day MA — liquidity
- Price < Bollinger Band upper — not at top

**Exit Rules:**
- Scalp: +2-3% profit (50% of position)
- Swing: Trail to EMA(8) (50% of position)
- Stop loss: -1.5% hard limit

**Tracking:** test-log.json records every decision (passed, blocked, win, loss)

### 2. Bridge Safety Integration
**Metric:** Safety blocks (should be 0 in testing, active when going live)  
**What's Being Verified:**
- Bridge server responds correctly at port 3001
- /trading-safe/:symbol endpoint validates conditions
- Bot calls validateBeforeTrade() before every order
- Safety check logs (bridge-safety-check-log.json) are clean

**Expected:** No safety blocks during paper trading (LIVE_MODE=false)  
**Action:** If safety blocks appear, investigate immediately

### 3. Bot Reliability
**Metric:** No unhandled errors, clean logs  
**Checks:**
- PM2 process runs continuously
- No crashes or unexpected restarts
- All indicators calculate correctly
- Test-log JSON stays valid

**Monitoring:**
```bash
# Check for errors
tail -50 ~/.pm2/logs/solana-trader-error.log

# Check uptime
pm2 list | grep solana-trader

# Validate test-log.json
cd /home/dh_ygjkxx/trading-bot-solana && node -e "console.log(JSON.parse(require('fs').readFileSync('test-log.json')).runs.length, 'runs')"
```

### 4. Pine Script Accuracy
**Metric:** Chart signals match bot decisions  
**What:** Add Pine Script to TradingView and compare green/red triangles to bot log  
**Steps:**
1. Copy `solana-scalp-strategy.pine` to TradingView
2. Open SOLUSDT 1H chart
3. For 3-5 past days: count green triangles (buy signals)
4. Check test-log.json: did bot enter at those times?
5. Verify alignment (>90% match expected)

---

## Daily Reporting

### What You'll See Each Morning

```
╔════════════════════════════════════════════════════════════╗
║       15-DAY TESTING REPORT — May 4, 2026, 8:00 AM EDT  ║
╚════════════════════════════════════════════════════════════╝

📊 Daily Summary:
   Checks run today: 24 (full day of hourly checks)
   Conditions met: 3
   Blocked (safety): 0

💰 Trade Results:
   Wins: 2
   Losses: 0
   Pending: 1
   Win Rate: 100%

📈 Overall Progress (Day 2 of 15):
   Total runs: 50
   Total wins: 35
   Total losses: 15
   Overall win rate: 70%
   Target: 60%+ | Status: ✅ PASSED

🔐 Safety:
   Safety blocks (total): 0
   Status: 🟢 PROTECTING ✓

═══════════════════════════════════════════════════════════════
```

### Interpretation

| Metric | Target | Action |
|--------|--------|--------|
| Win Rate | 60%+ | If below 60%, continue testing |
| Safety Blocks | 0 (in demo) | If > 0, investigate bridge connection |
| Run Count | 24/day | Should be ~24 (hourly). If < 10, check PM2 |
| Errors | 0 | Check logs if any appear |

---

## Decision Gates

### Day 5: Mid-Point Check
**What to verify:**
- Win rate is 50%+ (trending toward 60%)
- Bridge is stable (no errors)
- Pine Script signals match bot (>90%)
- No unexpected crashes

**Decision:**
- ✅ Continue testing
- ⚠️ Adjust strategy if needed, continue testing
- ❌ If major issues, stop and debug

### Day 10: Validation
**What to verify:**
- Win rate is 60%+ (target reached)
- 100+ total runs collected
- Safety system working correctly
- Ready for go-live

**Decision:**
- ✅ Ready to go live (proceed to Phase 2)
- ⏳ Close but not quite, continue testing until Day 15

### Day 15: Final Decision
**What to verify:**
- Win rate is 60%+ (consistently)
- No concerning errors in logs
- Bridge safety system is verified
- Confidence is high

**Decision:**
- ✅ **GO LIVE** — Switch LIVE_MODE=true, start with $100-200
- ⚠️ Inconclusive — Another 5 days testing OR adjust parameters
- ❌ Not ready — Debug issues before attempting real trading

---

## How to Go Live (When Ready)

### Step 1: Update Environment
```bash
# SSH to DreamHost
ssh dh_ygjkxx@vps48233.dreamhostps.com
cd /home/dh_ygjkxx/trading-bot-solana

# Edit .env
nano .env

# Change:
# LIVE_MODE=false → LIVE_MODE=true
# ALLOW_DEMO_DATA=true → ALLOW_DEMO_DATA=false
# PAPER_TRADING=true → PAPER_TRADING=false
# COINBASE_PORTFOLIO_VALUE=1000 (keep this)
# COINBASE_MAX_TRADE_SIZE=100 → COINBASE_MAX_TRADE_SIZE=100 (start small)

# Save and exit (Ctrl+X, Y, Enter)
```

### Step 2: Verify Safety System
```bash
# Test bridge safety check
curl http://localhost:3001/trading-safe/SOLUSDT

# Should return: "isSafeToTrade": true, "liveMode": true
```

### Step 3: Restart Bot
```bash
source ~/.nvm/nvm.sh
pm2 restart solana-trader
pm2 logs solana-trader

# Watch for 3 successful runs
```

### Step 4: Monitor First 24 Hours
- Check logs hourly
- If 10+ runs complete with no errors → Continue
- If any errors → Stop, investigate, fix

### Step 5: Scale Gradually
- **Days 1-7:** $100 max per trade (start small)
- **Days 8-14:** $200 max per trade (if no issues)
- **Day 15+:** $300-500 per trade (full size)

---

## Exit Criteria (Stop Testing If...)

**IMMEDIATE STOP:**
- Win rate drops below 40% for 2+ consecutive days
- Bridge safety system shows repeated failures
- Unhandled bot crashes (check PM2)
- Coinbase API errors (quota exceeded, auth failed)

**INVESTIGATION NEEDED:**
- Win rate is 50-59% on Day 10 (close but not there)
- Safety blocks appear frequently (bridge issue)
- Pine Script signals don't match bot (strategy issue)

**CONTINUE TESTING:**
- Win rate is 60%+ (on track)
- Bridge is stable
- No unexpected errors
- Confidence is building

---

## File Locations

### Test Logs (DreamHost)
```
/home/dh_ygjkxx/trading-bot-solana/test-log.json           — Daily tracking
/home/dh_ygjkxx/trading-bot-solana/trades.csv               — Tax record
/home/dh_ygjkxx/trading-bot-solana/safety-check-log.json    — Strategy log
/home/dh_ygjkxx/.pm2/logs/solana-trader-out.log             — Process output
/home/dh_ygjkxx/.pm2/logs/solana-trader-error.log           — Errors
```

### Local Backup (Workspace)
```
./test-log.json                    — Synced daily from DreamHost
./trades.csv                       — Tax record
./SOLANA_BOT_SUMMARY.md            — Status reference
```

---

## Daily Checklist

### Every Morning (8 AM)
- [ ] Read daily report (auto-generated)
- [ ] Review win rate (target 60%+)
- [ ] Check for safety blocks (expect 0)
- [ ] Verify no PM2 crashes

### Twice Weekly (Mon & Thu)
- [ ] Download test-log.json: `scp dh_ygjkxx@vps48233.dreamhostps.com:/home/dh_ygjkxx/trading-bot-solana/test-log.json ./`
- [ ] Run local analysis: `node bot.js --test-report`
- [ ] Update memory file if insights found

### Day 5, 10, 15
- [ ] Major checkpoint review (see Decision Gates above)
- [ ] Log observations in memory/YYYY-MM-DD.md
- [ ] Adjust strategy if needed (git commit any changes)

---

## Success Criteria

**Testing is successful when:**
- ✅ Win rate ≥ 60% (over 100+ runs)
- ✅ Safety system: 0 unintended blocks
- ✅ Bridge: stable, no connection errors
- ✅ Bot: no crashes, clean logs
- ✅ Confidence: High (ready for real money)

**Once all criteria met:** Proceed to Phase 2 (go live)

---

## Key Rules (Remember!)

🚨 **CRITICAL RULES:**

1. **NEVER skip the 15-day test period**
   - Real money trading without proof of 60%+ win rate = high risk of loss
   - 15 days = ~360 trades. That's statistical significance.

2. **NEVER trade with ALLOW_DEMO_DATA=true**
   - If LIVE_MODE=true AND ALLOW_DEMO_DATA=true → You're trading on fake data
   - Double-check .env before restarting

3. **NEVER increase trade size too fast**
   - Day 1: $100 max
   - After 1 week successful: $200 max
   - After 2 weeks successful: Full size

4. **ALWAYS monitor the first 24 hours**
   - Watch logs, check PM2 status
   - At least 10 successful hourly runs before stepping away

5. **ALWAYS backup test-log.json**
   - Download daily to workspace
   - Commit to git weekly
   - Lost data = lost progress

---

## Contact & Support

**Issues or questions?** Document findings and reach out:
- PM2 crashed? → Check PM2 logs, restart, verify in `pm2 list`
- Bridge error? → Check port 3001 with `curl http://localhost:3001/health`
- Win rate low? → Review recent trades in test-log.json, adjust strategy in rules.json
- Ready to go live? → Complete checklist above, update .env, restart bot

---

**Created:** May 3, 2026  
**Protocol Status:** ✅ ACTIVE  
**Next Milestone:** Day 15 checkpoint (May 17, 2026)

Good luck! Trade safely! 🎯
