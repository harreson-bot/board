# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

---

## Cloudflare — successmanufacturing.com
- **Zone ID:** 57ca8479496341690f27b41e582c11ba
- **Account ID:** 400ce880cf321fe0b5f32e74dda43d11
- **Domain:** successmanufacturing.com (added to Cloudflare, nameservers updating at Squarespace)
- **Tunnels:**
  - **rick-crm tunnel** (ACTIVE)
    - Tunnel ID: f0d15dc5-37c0-41d9-84c0-dd477789e956
    - Token: eyJhIjoiNDAwY2U4ODBjZjMyMWZlMGI1ZjMyZTc0ZGRhNDNkMTEiLCJ0IjoiZjBkMTVkYzUtMzdjMC00MWQ5LTg0YzAtZGQ0Nzc3ODllOTU2IiwicyI6Ik56WTBaalV4T1dRdFpURTNaaTAwTkRBNUxXRmtNR010Tm1aaU9EUXhPV1ZpT0RZNCJ9
    - Route: rick.successmanufacturing.com → localhost:3000
    - Start command: `/tmp/cloudflared-rick tunnel run --token [TOKEN]`

## Twilio — SMS/CRM
- **Console URL:** https://console.twilio.com
- **Account SID:** ACa424cbf3ec863b016a071c57d9688e62
- **Auth Token:** 0f603e8bc2eb32945c55604fad42cd03
- **Phone Number:** +1-352-755-7776
- **Messaging Service:** SMS via affordablehealthcare.solutions CRM
- **Webhook URL:** https://crm.affordablehealthcare.solutions/webhook.php
- **Use:** Send/receive SMS from WooSender-style CRM at crm.affordablehealthcare.solutions
- **A2P 10DLC Status:** Registration pending (required for US carrier compliance)

## WordPress — affordablehealthcare.solutions
- **Admin URL:** https://affordablehealthcare.solutions/wp-admin
- **Username:** calvenn@calvennstarre.com
- **Password:** #King$tarre22#
- **Application Password:** V80P FF12 Uud6 C8ZF UnkT 0lvY
- **Rule:** Draft only — nothing published without explicit approval

## WordPress — calvennstarre.com
- **Admin URL:** https://calvennstarre.com/wp-admin
- **Username:** calvenn@calvennstarre.com
- **Password:** #King$tarre22#
- **Application Password:** THwO vWqF E2NH fOkl eCEl 3cgU
- **App Name:** Harreson-CalvennMain
- **Status:** Live — personal website deployment

## Substack — Email Newsletter & Content Distribution
- **Publication URL:** https://affordablehealthcare.substack.com
- **Email:** calvenn@calvennstarre.com
- **API Status:** Read-only (approval pending, 7-10 days)
- **Content Focus:** Insurance tax strategies, healthcare affordability for self-employed/entrepreneurs
- **Automation:** Zapier RSS → LinkedIn auto-posting (see Zapier below)
- **Purpose:** Lead generation + thought leadership for affordablehealthcare.solutions

## Zapier — Automation & Workflows
- **Account URL:** https://zapier.com
- **Active Zaps:**
  1. **Substack RSS → LinkedIn**
     - Trigger: New post in affordablehealthcare.substack.com/feed
     - Action: Share Update on LinkedIn (personal profile @calvennstarre)
     - Status: Live
  2. **CRM Contact Form → Affordablehealthcare CRM** (in planning)
     - Trigger: WordPress form submission on affordablehealthcare.solutions
     - Action: Auto-import contact to crm.affordablehealthcare.solutions
- **Use:** Content distribution, CRM automation, SMS workflows

## CalvennStarre.com — Static HTML Website
- **Host:** vps48233.dreamhostps.com
- **SSH User:** cstarre
- **SSH Password:** #King$tarre26#
- **Directory:** /home/cstarre/public_html/ (or determine on first connection)
- **Type:** Static HTML (git-based deployment)
- **Status:** Live — contact form with reCAPTCHA v3 spam protection (May 1, 2026)

## Divi Theme by ElegantThemes
- **Site:** affordablehealthcare.solutions
- **Theme:** Divi (visual page builder)
- **Key Features:**
  - Divi Visual Page Builder (frontend editor)
  - Theme Customizer for site-wide styling
  - Divi Library for saving/reusing sections
  - Global Modules (update once, sync everywhere)
  - Responsive Design (mobile/tablet/desktop breakpoints)
- **Common modules:** Text, Image, Button, CTA, Image Gallery, Testimonials, Team Members, Features, Blurb, Icon List, Counters
- **Edit directly via frontend:** Divi Builder (no coding needed)

## DreamHost VPS — Shared (vps48233.dreamhostps.com)

**Three accounts on this shared VPS:**

### Main Panel Access
- **Panel URL:** panel.dreamhost.com
- **SSH Host:** vps48233.dreamhostps.com

### Harreson Account
- **SSH User:** dh_ygjkxx
- **SSH Password:** #KingBl@ckwell2026#
- **Command:** `ssh dh_ygjkxx@vps48233.dreamhostps.com`
- **Services:** memory-sync-api (PM2), engagement-crm (PM2), cloudflared-engagement (PM2)
- **Cloudflare Tunnel (engagement-crm):**
  - Tunnel ID: 190c4724-793b-4483-91cd-9377425e4044
  - Token: eyJhIjoiNDAwY2U4ODBjZjMyMWZlMGI1ZjMyZTc0ZGRhNDNkMTEiLCJ0IjoiMTkwYzQ3MjQtNzkzYi00NDgzLTkxY2QtOTM3NzQyNWU0MDQ0IiwicyI6Ik16WXhORGc1WlRjdFltTTFOaTAwWVRJd0xUaGtNREl0TWpGa056a3hOakZrWTJRNCJ9
  - Route: engage.calvennstarre.com → localhost:3000

### Rick Account (Success Manufacturing)
- **SSH User:** dh_mxb49v
- **SSH Password:** #Reve@lRick26#
- **Domain:** rick.successmanufacturing.com
- **Services:** rick-crm (PM2) + cloudflared tunnel (auto-restart on VPS reboot)

### Angel Account (Engagement CRM)
- **SSH User:** dh_tcjj4a
- **SSH Password:** #King@ngel26#
- **Domain:** angel.successmanufacturing.com
- **App Port:** 3002 (localhost)
- **Services:** angel-crm (PM2) + cloudflared tunnel
- **Database:** SQLite (data/angel.db)
- **Features:** Flexible CSV/VCF importer, duplicate detection, Import only (no Export)
- **Cloudflare Tunnel:**
  - Tunnel ID: 79fcd76b-c970-42a5-9140-cee94a88dff2
  - Authentication: Cloudflare Zero Trust (email magic link)

### CRM Account (Affordable Healthcare Solutions)
- **SSH User:** dh_q2jj8c
- **SSH Password:** #H@rreson26#
- **Domain:** crm.affordablehealthcare.solutions
- **App Port:** Default (80/443)
- **Services:** WooSender-style CRM (PHP + SQLite)
- **CRM Login Password:** Calvenn2026!
- **SSH Public Key (Harreson):** ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPgKPHqbD/wIvAVEnVfsztQCSKcjp4Mu1rOkSrjk3t7V harreson@openclaw
- **SSH Public Key (Legacy):** ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIVWEIlO12caIdQoqbkWac4l2YdeR4BM9deFu2O/jbXg harreson@openclaw
- **Features:** Contact management, SMS compose (via Twilio), inbox/threading, TCPA compliance, opt-out handling

## PatchHub — White-Label SaaS Platform (NEW | May 5, 2026)

### Marketing Site (patchhub.solutions)
- **Host:** vps48233.dreamhostps.com
- **SSH User:** dh_edrxnc
- **SSH Password:** #KingP@tch26#
- **Type:** Static HTML (easy to white-label for resale)
- **Deployment:** Git-based

### Platform (app.patchhub.solutions)
- **Host:** vps48233.dreamhostps.com
- **SSH User:** patch_app
- **SSH Password:** #KingP@tch26#
- **Type:** Node.js/Express backend + React frontend
- **Database:** PostgreSQL (per-customer isolation)
- **Deployment:** Docker containerized
- **Both on shared VPS, SSH enabled**

## Trello
- **API Key:** 452a8242ea0e3cb8078148fa585f445f
- **Token:** ATTA420b1357f3b228101915991a64fa7400aa2f75b20e6c0e4ac3992a18d42c8f467DB8A2B5
- **Harreson Board:** https://trello.com/b/1R3S7GZJ/harreson (Board ID: 69e6c29d97be38700451d63b)
- **Lists:** To Do (69e6c2a4a2b3dba16007478e) | In Progress (69e6c2a4d2f072db6a7c1c1f) | Done (69e6c2a50ccc878b9ce82a3d)

## GitHub
- **Account:** Harreson-bot
- **Primary repo:** workspace-backup (private, synced daily)
- **Use:** Version control for CalvennStarre projects, engagement-crm, memory-sync, PatchHub

## SOLANA Trading Bot — DreamHost Deployment (May 3, 2026)

### Live Bot Details
- **Host:** vps48233.dreamhostps.com
- **SSH User:** dh_ygjkxx
- **SSH Password:** #KingBl@ckwell2026#
- **Bot Directory:** `/home/dh_ygjkxx/trading-bot-solana/`
- **Process Name:** solana-trader (running via PM2)
- **Cron Schedule:** Every hour (0 * * * * = 00:00, 01:00, 02:00, etc.)
- **Exchange:** Coinbase Advanced
- **Trading Pair:** SOLUSDT (Solana)
- **Paper Trading:** Enabled (no real money yet)
- **Portfolio Value:** $1,000 USD
- **Max Trade Size:** $200 USD (2 trades/day max)

### PM2 Commands
```bash
SSH into dh_ygjkxx@vps48233.dreamhostps.com
source ~/.nvm/nvm.sh
pm2 list                              # See all processes
pm2 logs solana-trader                # View realtime logs
pm2 stop solana-trader                # Pause bot
pm2 restart solana-trader             # Restart bot
pm2 delete solana-trader              # Remove from PM2
```

### Strategy
- **Timeframe:** 1-hour candles (catches SOLANA dips in $80-85 range)
- **Entry:** RSI < 40 (pullback) + EMA(8) > EMA(21) (uptrend) + Volume confirm
- **Exit:** +2-3% profit (scalp) or -1.5% stop loss
- **Bias:** Hold 50% for swing, scalp 50% for daily profit

### Log Files
- **Main output:** `/home/dh_ygjkxx/.pm2/logs/solana-trader-out.log`
- **Errors:** `/home/dh_ygjkxx/.pm2/logs/solana-trader-error.log`
- **Safety check:** `/home/dh_ygjkxx/trading-bot-solana/safety-check-log.json`
- **Trades record:** `/home/dh_ygjkxx/trading-bot-solana/trades.csv`

### Git Repository
- **Clone URL:** https://github.com/jackson-video-resources/claude-tradingview-mcp-trading
- **Local path:** `/home/harreson/.openclaw/workspace/claude-tradingview-mcp-trading/`
- **Status:** Cloned May 3, configured for Coinbase, deployed to DreamHost

## Blog Post Tracking
### Georgia (✅ PUBLISHED May 1, 2026)
- **URL:** https://affordablehealthcare.solutions/affordable-health-insurance-self-employed-georgia/
- **Post ID:** 314
- **Status:** Live
- **Keyword:** "affordable health insurance self-employed georgia"
