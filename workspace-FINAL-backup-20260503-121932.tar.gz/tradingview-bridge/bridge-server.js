/**
 * TradingView Bridge Server
 * 
 * Persistent connection to TradingView data feeds
 * Provides live OHLCV data via REST API + WebSocket
 * Reusable across all trading projects
 * 
 * Usage: node bridge-server.js
 */

import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'http';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Configuration
const CONFIG = {
  port: process.env.BRIDGE_PORT || 3001,
  tvWebsocketUrl: 'wss://data.tradingview.com/socket.io/?EIO=4&transport=websocket',
  liveMode: process.env.LIVE_MODE === 'true',
  allowDemoData: process.env.ALLOW_DEMO_DATA !== 'false',
  symbols: {
    'SOLUSDT': { exchange: 'BINANCE', tf: '60' },
    'BTCUSDT': { exchange: 'BINANCE', tf: '60' },
    'ETHUSDT': { exchange: 'BINANCE', tf: '60' },
  },
  cacheExpiry: 60000,
  maxCandlesPerSymbol: 100,
  requiredLiveDataUptime: 300000,
};

// In-memory data store
const dataStore = {
  candles: {},
  lastUpdate: {},
  lastLiveUpdate: {},
  isLiveData: {},
  clients: new Set(),
  demoWarnings: [],
  liveConnectedAt: null,
};

// Initialize candle storage
Object.keys(CONFIG.symbols).forEach(symbol => {
  dataStore.candles[symbol] = [];
  dataStore.lastUpdate[symbol] = 0;
  dataStore.lastLiveUpdate[symbol] = 0;
  dataStore.isLiveData[symbol] = false;
});

// Start with demo data if allowed
if (CONFIG.allowDemoData) {
  Object.keys(CONFIG.symbols).forEach(symbol => {
    dataStore.candles[symbol] = generateDemoCandles(symbol, 50);
    dataStore.lastUpdate[symbol] = Date.now();
    dataStore.isLiveData[symbol] = false;
  });
  console.log('[Bridge] Initialized with demo data (waiting for TradingView connection)');
} else {
  console.log('[Bridge] LIVE MODE ACTIVE - Demo data disabled. Waiting for live TradingView data...');
}

// ═════════════════════════════════════════════════════════════════════════════
// REST API Endpoints
// ═════════════════════════════════════════════════════════════════════════════

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    tvConnected: false, // Demo mode - no real TradingView yet
    symbols: Object.keys(CONFIG.symbols),
    dataPoints: Object.entries(dataStore.candles).reduce((acc, [symbol, candles]) => {
      acc[symbol] = candles.length;
      return acc;
    }, {}),
    timestamp: new Date().toISOString(),
  });
});

app.get('/candles/:symbol', (req, res) => {
  const { symbol } = req.params;
  const { limit = 20 } = req.query;

  if (!CONFIG.symbols[symbol]) {
    return res.status(404).json({
      error: 'Symbol not supported',
      supported: Object.keys(CONFIG.symbols),
    });
  }

  const candles = dataStore.candles[symbol] || [];
  const recentCandles = candles.slice(-Math.min(limit, candles.length));

  res.json({
    symbol,
    timeframe: CONFIG.symbols[symbol].tf,
    count: recentCandles.length,
    data: recentCandles,
    lastUpdate: dataStore.lastUpdate[symbol],
  });
});

app.get('/latest/:symbol', (req, res) => {
  const { symbol } = req.params;

  if (!CONFIG.symbols[symbol]) {
    return res.status(404).json({ error: 'Symbol not supported' });
  }

  const candles = dataStore.candles[symbol] || [];
  const latest = candles[candles.length - 1] || null;

  res.json({
    symbol,
    latest,
    lastUpdate: dataStore.lastUpdate[symbol],
  });
});

app.get('/indicators/:symbol', (req, res) => {
  const { symbol } = req.params;

  if (!CONFIG.symbols[symbol]) {
    return res.status(404).json({ error: 'Symbol not supported' });
  }

  const candles = dataStore.candles[symbol] || [];
  if (candles.length < 21) {
    return res.status(400).json({
      error: 'Insufficient candles for indicators',
      needed: 21,
      available: candles.length,
    });
  }

  const indicators = calculateIndicators(candles);
  
  const now = Date.now();
  const isLiveData = dataStore.isLiveData[symbol];
  const dataIsRecent = (now - dataStore.lastUpdate[symbol]) < 60000;
  const tvConnected = false;
  const tradingSafe = isLiveData && dataIsRecent && tvConnected && !CONFIG.liveMode;

  res.json({
    symbol,
    timeframe: CONFIG.symbols[symbol].tf,
    indicators,
    lastUpdate: dataStore.lastUpdate[symbol],
    candleCount: candles.length,
    dataSource: {
      isLiveData: isLiveData,
      dataAgeMs: now - dataStore.lastUpdate[symbol],
      tvConnected: tvConnected,
      liveMode: CONFIG.liveMode,
    },
    tradingSafe: tradingSafe,
    warning: CONFIG.liveMode && !isLiveData ? 'WARNING: Using demo data in LIVE MODE!' : null,
  });
});

app.get('/status', (req, res) => {
  const status = {
    bridge: {
      running: true,
      uptime: process.uptime(),
      port: CONFIG.port,
      liveMode: CONFIG.liveMode,
      allowDemoData: CONFIG.allowDemoData,
    },
    tradingview: {
      connected: false,
      connectionAttempts: 0,
      url: CONFIG.tvWebsocketUrl,
      liveConnectedSince: dataStore.liveConnectedAt ? new Date(dataStore.liveConnectedAt).toISOString() : null,
    },
    data: {
      symbols: Object.keys(CONFIG.symbols),
      candles: Object.entries(dataStore.candles).reduce((acc, [symbol, candles]) => {
        acc[symbol] = {
          count: candles.length,
          oldest: candles[0]?.t,
          newest: candles[candles.length - 1]?.t,
          lastUpdate: new Date(dataStore.lastUpdate[symbol]).toISOString(),
          lastLiveUpdate: dataStore.lastLiveUpdate[symbol] ? new Date(dataStore.lastLiveUpdate[symbol]).toISOString() : 'NEVER',
          isLiveData: dataStore.isLiveData[symbol],
        };
        return acc;
      }, {}),
    },
    clients: {
      websocket: dataStore.clients.size,
    },
    timestamp: new Date().toISOString(),
  };

  res.json(status);
});

app.get('/trading-safe/:symbol', (req, res) => {
  const { symbol } = req.params;

  if (!CONFIG.symbols[symbol]) {
    return res.status(404).json({ error: 'Symbol not supported' });
  }

  const candles = dataStore.candles[symbol] || [];
  const now = Date.now();
  const timeSinceLastUpdate = now - dataStore.lastUpdate[symbol];
  const timeSinceLiveData = now - dataStore.lastLiveUpdate[symbol];
  const tvConnected = false;
  const isLiveData = dataStore.isLiveData[symbol];
  const hasEnoughCandles = candles.length >= 21;
  const dataIsRecent = timeSinceLastUpdate < 60000;

  const checks = {
    tvConnected: {
      passed: tvConnected,
      message: tvConnected ? 'TradingView connected' : 'TradingView NOT connected - no live data source',
    },
    isLiveData: {
      passed: isLiveData,
      message: isLiveData ? 'Live data currently flowing' : 'DEMO data only - NOT safe for real trading',
    },
    dataIsRecent: {
      passed: dataIsRecent,
      message: dataIsRecent ? `Data fresh (${timeSinceLastUpdate}ms old)` : `Data STALE (${timeSinceLastUpdate}ms old)`,
    },
    hasEnoughCandles: {
      passed: hasEnoughCandles,
      message: hasEnoughCandles ? `Sufficient candles: ${candles.length}` : `NOT ENOUGH: ${candles.length}/21 needed`,
    },
  };

  const isSafeToTrade = Object.values(checks).every(c => c.passed);

  if (!isSafeToTrade && CONFIG.liveMode) {
    console.error(`[SAFETY] UNSAFE TO TRADE ${symbol}:`, checks);
    dataStore.demoWarnings.push({
      symbol,
      timestamp: new Date().toISOString(),
      reason: Object.entries(checks)
        .filter(([_, check]) => !check.passed)
        .map(([name, check]) => `${name}: ${check.message}`)
        .join(' | '),
    });
  }

  res.json({
    symbol,
    isSafeToTrade,
    liveMode: CONFIG.liveMode,
    allowDemoData: CONFIG.allowDemoData,
    checks,
    details: {
      timeSinceLastUpdate: `${timeSinceLastUpdate}ms`,
      timeSinceLiveData: timeSinceLiveData > 0 ? `${timeSinceLiveData}ms` : 'NEVER',
      candleCount: candles.length,
      tvConnected,
      isLiveData,
    },
    timestamp: new Date().toISOString(),
  });
});

app.get('/safety-warnings', (req, res) => {
  res.json({
    liveMode: CONFIG.liveMode,
    allowDemoData: CONFIG.allowDemoData,
    totalWarnings: dataStore.demoWarnings.length,
    warnings: dataStore.demoWarnings.slice(-50),
    timestamp: new Date().toISOString(),
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// WebSocket Connections
// ═════════════════════════════════════════════════════════════════════════════

wss.on('connection', (ws) => {
  console.log(`[WebSocket] Client connected (${dataStore.clients.size + 1} total)`);
  dataStore.clients.add(ws);

  ws.send(JSON.stringify({
    type: 'connected',
    message: 'Connected to TradingView Bridge',
    symbols: Object.keys(CONFIG.symbols),
    timestamp: new Date().toISOString(),
  }));

  ws.on('message', (message) => {
    try {
      const msg = JSON.parse(message);
      
      if (msg.action === 'subscribe') {
        const { symbol } = msg;
        if (CONFIG.symbols[symbol]) {
          ws.symbol = symbol;
          ws.send(JSON.stringify({
            type: 'subscribed',
            symbol,
            timestamp: new Date().toISOString(),
          }));
          console.log(`[WebSocket] Client subscribed to ${symbol}`);
        } else {
          ws.send(JSON.stringify({
            type: 'error',
            message: `Unknown symbol: ${symbol}`,
          }));
        }
      }
    } catch (err) {
      console.error('[WebSocket] Parse error:', err.message);
    }
  });

  ws.on('close', () => {
    dataStore.clients.delete(ws);
    console.log(`[WebSocket] Client disconnected (${dataStore.clients.size} remaining)`);
  });

  ws.on('error', (err) => {
    console.error('[WebSocket] Error:', err.message);
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// Indicator Calculations
// ═════════════════════════════════════════════════════════════════════════════

function calculateIndicators(candles) {
  const closes = candles.map(c => c.c);
  const volumes = candles.map(c => c.v);

  const ema8 = calculateEMA(closes, 8);
  const ema21 = calculateEMA(closes, 21);
  const rsi = calculateRSI(closes, 14);
  const bb = calculateBollingerBands(closes, 20, 2);
  const volumeSMA = calculateSMA(volumes, 20);

  return {
    ema8: ema8[ema8.length - 1],
    ema21: ema21[ema21.length - 1],
    rsi: rsi[rsi.length - 1],
    bollingerBands: {
      upper: bb.upper[bb.upper.length - 1],
      middle: bb.middle[bb.middle.length - 1],
      lower: bb.lower[bb.lower.length - 1],
    },
    volumeSMA: volumeSMA[volumeSMA.length - 1],
    close: closes[closes.length - 1],
    timestamp: new Date().toISOString(),
  };
}

function calculateEMA(prices, period) {
  const ema = [];
  const multiplier = 2 / (period + 1);

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += prices[i];
  }
  ema[period - 1] = sum / period;

  for (let i = period; i < prices.length; i++) {
    ema[i] = (prices[i] * multiplier) + (ema[i - 1] * (1 - multiplier));
  }

  return ema;
}

function calculateRSI(prices, period) {
  const rsi = [];
  let gains = 0;
  let losses = 0;

  for (let i = 1; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) gains += change;
    else losses += Math.abs(change);

    if (i === period) {
      const avgGain = gains / period;
      const avgLoss = losses / period;
      const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
      rsi[i] = 100 - (100 / (1 + rs));
    } else if (i > period) {
      const avgGain = (gains / period);
      const avgLoss = (losses / period);
      const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
      rsi[i] = 100 - (100 / (1 + rs));
    }
  }

  return rsi;
}

function calculateBollingerBands(prices, period, stdDev) {
  const sma = calculateSMA(prices, period);
  const upper = [];
  const middle = sma;
  const lower = [];

  for (let i = period - 1; i < prices.length; i++) {
    const subset = prices.slice(i - period + 1, i + 1);
    const mean = subset.reduce((a, b) => a + b) / period;
    const variance = subset.reduce((sq, n) => sq + Math.pow(n - mean, 2)) / period;
    const std = Math.sqrt(variance);

    upper[i] = mean + (std * stdDev);
    lower[i] = mean - (std * stdDev);
  }

  return { upper, middle, lower };
}

function calculateSMA(prices, period) {
  const sma = [];
  for (let i = period - 1; i < prices.length; i++) {
    const subset = prices.slice(i - period + 1, i + 1);
    sma[i] = subset.reduce((a, b) => a + b) / period;
  }
  return sma;
}

// ═════════════════════════════════════════════════════════════════════════════
// Demo Data Generation
// ═════════════════════════════════════════════════════════════════════════════

function generateDemoCandles(symbol, count = 50) {
  const candles = [];
  let price = 85;

  for (let i = 0; i < count; i++) {
    const open = price;
    const volatility = Math.random() * 2 - 1;
    const close = price + volatility;
    const high = Math.max(open, close) + Math.random() * 0.5;
    const low = Math.min(open, close) - Math.random() * 0.5;
    const volume = Math.floor(Math.random() * 1000000) + 500000;

    candles.push({
      t: Date.now() - (count - i - 1) * 3600000,
      o: open,
      h: high,
      l: low,
      c: close,
      v: volume,
    });

    price = close;
  }

  return candles;
}

// ═════════════════════════════════════════════════════════════════════════════
// Server Startup
// ═════════════════════════════════════════════════════════════════════════════

server.listen(CONFIG.port, () => {
  const modeLabel = CONFIG.liveMode ? '🔴 LIVE MODE' : '🟢 DEMO MODE';
  const demoStatus = CONFIG.allowDemoData ? '(Demo data enabled)' : '(Demo data DISABLED - Real data required)';
  
  console.log(`
╔════════════════════════════════════════════════════════════════════════════╗
║                                                                            ║
║               TradingView Bridge Server STARTED                            ║
║               ${modeLabel} ${demoStatus}                ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝

📊 REST API:
   http://localhost:${CONFIG.port}/health                    ← Status check
   http://localhost:${CONFIG.port}/candles/SOLUSDT           ← Latest candles
   http://localhost:${CONFIG.port}/latest/SOLUSDT            ← Latest candle only
   http://localhost:${CONFIG.port}/indicators/SOLUSDT        ← Live indicators
   http://localhost:${CONFIG.port}/status                    ← Full status
   http://localhost:${CONFIG.port}/trading-safe/SOLUSDT      ← SAFETY CHECK
   http://localhost:${CONFIG.port}/safety-warnings           ← Safety log

🔌 WebSocket:
   ws://localhost:${CONFIG.port}                             ← Real-time updates

📡 TradingView Connection:
   Status: Demo mode (real data awaiting connection)
   Using simulated demo candles for testing

`);
});

// Logging
setInterval(() => {
  const symbolsWithLiveData = Object.entries(dataStore.isLiveData)
    .filter(([_, isLive]) => isLive)
    .map(([symbol, _]) => symbol);
  
  if (CONFIG.liveMode) {
    console.log(`[LIVE MODE CHECK] Live symbols: ${symbolsWithLiveData.join(',') || 'NONE - using demo data'}`);
  }
}, 30000);

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[Bridge] Shutting down gracefully...');
  server.close(() => {
    console.log('[Bridge] Server closed');
    process.exit(0);
  });
});

export { app, wss, dataStore };
