# 🔴 LIVE TRADING SAFETY PROTOCOL

**CRITICAL DOCUMENT** — Read before trading with REAL money

---

## The Problem You're Solving

❌ **Risk:** Demo data accidentally used in real trading = real money loss  
✅ **Solution:** Bridge enforces live data requirement when LIVE_MODE=true

---

## Configuration States

### 1️⃣ DEVELOPMENT MODE (Testing with demo data)
```env
LIVE_MODE=false
ALLOW_DEMO_DATA=true
```
**When to use:** First deployment, strategy testing, backtesting  
**Safety:** Demo data is used, no real money at risk  
**Trading blocked:** YES (safe to develop)

---

### 2️⃣ LIVE TRADING MODE (Real money - MAXIMUM SAFETY)
```env
LIVE_MODE=true
ALLOW_DEMO_DATA=false
```
**When to use:** When trading with REAL crypto/money  
**Safety:** ONLY live data accepted, demo data BLOCKED  
**Trading blocked:** YES if live data unavailable (safe!)

---

## ⚠️ NEVER DO THIS

```env
# DANGEROUS: Real money trades with fake data!
LIVE_MODE=true
ALLOW_DEMO_DATA=true
```
❌ This allows real money orders based on demo data  
❌ Bridge will send safety warnings but may still trade  
❌ YOU WILL LOSE MONEY

---

## Pre-Live Checklist

Before switching to LIVE_MODE=true, complete these steps:

### Step 1: Test with Demo Data (1-2 weeks)
```bash
LIVE_MODE=false
ALLOW_DEMO_DATA=true
```
✅ Let bot run with demo data for 15+ days  
✅ Verify strategy is profitable (60%+ win rate)  
✅ Check that indicators make sense  
✅ Monitor bot logs for errors

---

### Step 2: Verify TradingView Connection (24 hours)
```bash
# Check if bridge is getting LIVE data
curl http://localhost:3001/status | jq '.data.symbols[].isLiveData'

# Should show: true for all symbols
```
✅ TradingView must be connected  
✅ Bridge must be receiving live OHLCV data  
✅ Data must be fresh (< 60 seconds old)

---

### Step 3: Run Trading Safety Check
```bash
# Before EVERY real trade, call this endpoint:
curl http://localhost:3001/trading-safe/SOLUSDT

# Response should be:
{
  "isSafeToTrade": true,
  "checks": {
    "tvConnected": { "passed": true },
    "isLiveData": { "passed": true },
    "dataIsRecent": { "passed": true },
    "hasEnoughCandles": { "passed": true }
  }
}
```
✅ All checks MUST PASS  
✅ If any fails → DO NOT TRADE  
✅ Fix the issue first

---

### Step 4: Update Bot to Check Safety

Add this to your bot BEFORE placing ANY real trade:

```javascript
import { BridgeClient } from '../tradingview-bridge/bridge-client.js'

const bridge = new BridgeClient('http://localhost:3001')

async function canExecuteTrade(symbol) {
  const response = await fetch(`http://localhost:3001/trading-safe/${symbol}`)
  const data = await response.json()
  
  if (!data.isSafeToTrade) {
    console.error(`[SAFETY] UNSAFE TO TRADE ${symbol}:`, data.checks)
    return false // Block trade
  }
  
  return true // Safe to trade
}

// In bot's trade logic:
if (await canExecuteTrade('SOLUSDT')) {
  // Execute trade
  executeOrder(...)
} else {
  console.log('Blocked unsafe trade')
}
```

---

### Step 5: Final Safety Check

```bash
# 1. Verify .env settings
grep -E "LIVE_MODE|ALLOW_DEMO_DATA" .env

# Should be EXACTLY:
# LIVE_MODE=true
# ALLOW_DEMO_DATA=false

# 2. Check bridge is running
curl http://localhost:3001/health

# 3. Verify live data is flowing
curl http://localhost:3001/status | jq '.data'

# 4. Test trading-safe endpoint
curl http://localhost:3001/trading-safe/SOLUSDT

# 5. Check logs
pm2 logs tv-bridge
```

All must pass ✓

---

## The Three Layers of Safety

### Layer 1: Environment Variables
```env
LIVE_MODE=true          # Intent: use real money
ALLOW_DEMO_DATA=false   # Enforcement: block demo data
```
If both are set correctly, bridge cannot use fake data.

### Layer 2: Runtime Checks
```javascript
if (tvConnected && isLiveData && dataIsRecent && hasEnoughCandles) {
  return { isSafeToTrade: true }
}
```
Bridge validates conditions on every API call.

### Layer 3: Bot Logic
```javascript
if (await canExecuteTrade(symbol)) {
  // Only executes if trading-safe endpoint returns true
  executeOrder(...)
}
```
Bot double-checks before placing order.

---

## What "Live Data" Means

**Live data** = Real OHLCV candles from TradingView  
✅ Connected to TradingView WebSocket  
✅ Receiving actual market data  
✅ Data is < 60 seconds old  
✅ 21+ candles available for indicators

**Demo data** = Synthetic candles generated locally  
❌ Not from TradingView  
❌ Good for testing, bad for real trading  
❌ Will cause money loss if used accidentally

---

## Monitoring Live Trading

Once LIVE_MODE=true:

### Daily Check (5 seconds)
```bash
curl http://localhost:3001/health | jq '.tvConnected'
# Should return: true
```

### Every Hour (before bot runs)
```bash
curl http://localhost:3001/trading-safe/SOLUSDT | jq '.isSafeToTrade'
# Should return: true
```

### Check Safety Violations
```bash
curl http://localhost:3001/safety-warnings | jq '.warnings'
# Should return: [] (empty - no violations)
```

### Monitor Real-Time
```bash
pm2 logs tv-bridge | grep -i "LIVE MODE CHECK"
# Logs every 30 seconds with status
```

---

## If Something Goes Wrong

### Bridge not connected to TradingView
```
[SAFETY ALERT] LIVE MODE ACTIVE but no live data!
```
→ **DO NOT TRADE**  
→ Check TradingView desktop is running  
→ Check firewall/network  
→ Fix before trading

### Data is stale
```
"dataIsRecent": { "passed": false, "message": "Data STALE (65000ms old)" }
```
→ **DO NOT TRADE**  
→ Wait for new candle  
→ Verify TradingView is streaming

### Insufficient candles
```
"hasEnoughCandles": { "passed": false, "message": "NOT ENOUGH: 15/21 needed" }
```
→ **DO NOT TRADE**  
→ Wait for more candles to load  
→ Takes ~21 hours on 1H timeframe

---

## Emergency: Disable Live Trading

If something feels wrong and you want to STOP trading immediately:

```bash
# SSH into DreamHost
ssh dh_ygjkxx@vps48233.dreamhostps.com

# Switch back to safe mode
cd /home/dh_ygjkxx/trading-bot-solana
nano .env
# Change: PAPER_TRADING=false → PAPER_TRADING=true
# Save: Ctrl+X → Y → Enter

# AND in the bridge:
cd /home/dh_ygjkxx/tradingview-bridge
nano .env
# Change: LIVE_MODE=true → LIVE_MODE=false
# Save: Ctrl+X → Y → Enter

# Restart both
pm2 restart solana-trader tv-bridge
```

Now you're back in **DEMO MODE** - no real money at risk.

---

## Compliance Checklist

Print this and sign before going live:

```
□ I have read this entire document
□ I understand the risks of live trading
□ I have tested the bot with demo data for 15+ days
□ I have verified strategy win rate is 60%+
□ I have confirmed TradingView is connected and sending live data
□ I have added trading-safe check to my bot code
□ I have tested the trading-safe endpoint locally
□ I have set .env to: LIVE_MODE=true AND ALLOW_DEMO_DATA=false
□ I have run the 5-step pre-live checklist above
□ I understand that I am responsible for any money lost
□ I am starting with small amounts ($100-200 first week)
□ I have a plan to stop if losses exceed $50/day

Signed: _____________________  Date: ___________
```

---

## Support Resources

### If bridge crashes
- PM2 auto-restarts it (usually)
- Check logs: `pm2 logs tv-bridge`
- Restart manually: `pm2 restart tv-bridge`

### If TradingView disconnects
- Bridge retries (up to 5 times)
- Fallback to demo data (if ALLOW_DEMO_DATA=true)
- In LIVE_MODE, this blocks trading (safe!)

### If bot doesn't execute
- Check trading-safe endpoint
- Verify live data is available
- Check bot logs for errors
- Verify you have sufficient funds in Coinbase

---

## Key Takeaway

**✅ Safe for real trading:**
1. LIVE_MODE=true
2. ALLOW_DEMO_DATA=false
3. Trading-safe check passes
4. TradingView connected with live data

**❌ Unsafe for real trading:**
1. LIVE_MODE=true + ALLOW_DEMO_DATA=true (bad!)
2. Trading-safe check fails
3. No trading-safe check in bot
4. TradingView not connected

---

**You have built automated trading infrastructure. Don't gamble with it.**

**Safety > Speed. Always.**

---

Document Version: 1.0  
Created: May 3, 2026  
Last Updated: May 3, 2026  
Status: LIVE
