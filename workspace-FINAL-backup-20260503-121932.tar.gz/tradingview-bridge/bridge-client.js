/**
 * TradingView Bridge Client
 * 
 * Use this in any trading bot or project to get live data from the bridge
 * 
 * Usage:
 *   import { BridgeClient } from './bridge-client.js'
 *   const client = new BridgeClient('http://localhost:3001')
 *   const indicators = await client.getIndicators('SOLUSDT')
 *   console.log(indicators.rsi, indicators.ema8, indicators.ema21)
 */

export class BridgeClient {
  constructor(baseUrl = 'http://localhost:3001') {
    this.baseUrl = baseUrl;
    this.ws = null;
    this.subscriptions = new Map();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
  }

  /**
   * Check if bridge is healthy
   */
  async health() {
    try {
      const response = await fetch(`${this.baseUrl}/health`);
      return await response.json();
    } catch (err) {
      console.error('[BridgeClient] Health check failed:', err.message);
      return { status: 'error', error: err.message };
    }
  }

  /**
   * Get latest candles for a symbol
   * @param {string} symbol - e.g., 'SOLUSDT'
   * @param {number} limit - Number of candles to return (default 20)
   */
  async getCandles(symbol, limit = 20) {
    try {
      const response = await fetch(
        `${this.baseUrl}/candles/${symbol}?limit=${limit}`
      );
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return await response.json();
    } catch (err) {
      console.error(`[BridgeClient] Failed to get candles for ${symbol}:`, err.message);
      throw err;
    }
  }

  /**
   * Get only the most recent candle (fast lookup)
   * @param {string} symbol - e.g., 'SOLUSDT'
   */
  async getLatestCandle(symbol) {
    try {
      const response = await fetch(`${this.baseUrl}/latest/${symbol}`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return data.latest;
    } catch (err) {
      console.error(`[BridgeClient] Failed to get latest candle for ${symbol}:`, err.message);
      throw err;
    }
  }

  /**
   * Get all indicators for a symbol
   * Returns: EMA(8), EMA(21), RSI(14), Bollinger Bands, Volume SMA
   * @param {string} symbol - e.g., 'SOLUSDT'
   */
  async getIndicators(symbol) {
    try {
      const response = await fetch(`${this.baseUrl}/indicators/${symbol}`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return data.indicators;
    } catch (err) {
      console.error(`[BridgeClient] Failed to get indicators for ${symbol}:`, err.message);
      throw err;
    }
  }

  /**
   * Get detailed status of the bridge
   */
  async getStatus() {
    try {
      const response = await fetch(`${this.baseUrl}/status`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return await response.json();
    } catch (err) {
      console.error('[BridgeClient] Failed to get status:', err.message);
      throw err;
    }
  }

  /**
   * Connect to WebSocket for real-time updates
   * @param {Function} onMessage - Callback for incoming messages
   */
  connectWebSocket(onMessage) {
    const wsUrl = this.baseUrl.replace('http', 'ws');
    console.log(`[BridgeClient] Connecting to WebSocket: ${wsUrl}`);

    this.ws = new WebSocket(wsUrl);

    this.ws.onopen = () => {
      console.log('[BridgeClient] WebSocket connected ✓');
      this.reconnectAttempts = 0;
    };

    this.ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (onMessage) {
          onMessage(message);
        }
      } catch (err) {
        console.error('[BridgeClient] WebSocket parse error:', err.message);
      }
    };

    this.ws.onclose = () => {
      console.log('[BridgeClient] WebSocket closed. Reconnecting...');
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        this.reconnectAttempts++;
        setTimeout(() => this.connectWebSocket(onMessage), 3000 * this.reconnectAttempts);
      } else {
        console.error('[BridgeClient] Max WebSocket reconnection attempts reached');
      }
    };

    this.ws.onerror = (err) => {
      console.error('[BridgeClient] WebSocket error:', err);
    };
  }

  /**
   * Subscribe to a symbol via WebSocket
   * @param {string} symbol - e.g., 'SOLUSDT'
   */
  subscribe(symbol) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.error('[BridgeClient] WebSocket not connected');
      return;
    }

    this.ws.send(JSON.stringify({
      action: 'subscribe',
      symbol,
    }));

    this.subscriptions.set(symbol, true);
    console.log(`[BridgeClient] Subscribed to ${symbol}`);
  }

  /**
   * Close WebSocket connection
   */
  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.subscriptions.clear();
      console.log('[BridgeClient] Disconnected');
    }
  }
}

/**
 * Helper: Quick indicator check
 * @param {BridgeClient} client - Bridge client instance
 * @param {string} symbol - e.g., 'SOLUSDT'
 * @returns {object} - { rsi, ema8, ema21, bb, volumeSMA }
 */
export async function checkSignal(client, symbol) {
  try {
    const indicators = await client.getIndicators(symbol);
    return {
      rsi: indicators.rsi,
      ema8: indicators.ema8,
      ema21: indicators.ema21,
      bollingerBands: indicators.bollingerBands,
      volumeSMA: indicators.volumeSMA,
      close: indicators.close,
      timestamp: indicators.timestamp,
    };
  } catch (err) {
    console.error('[checkSignal] Failed:', err.message);
    throw err;
  }
}

/**
 * Helper: Check if buy conditions are met
 */
export function isBuySignal(indicators, latestCandle) {
  if (!indicators || !latestCandle) return false;

  const {
    rsi,
    ema8,
    ema21,
    bollingerBands,
    volumeSMA,
    close,
  } = indicators;

  // 6 conditions for SOLANA scalp strategy
  const bullishTrend = close > ema21;
  const bullishMomentum = ema8 > ema21;
  const rsiOversold = rsi < 40;
  const rsiRecovery = rsi > 45;
  const volumeConfirmed = latestCandle.v > volumeSMA;
  const notAtTop = close < bollingerBands.upper;

  return (
    bullishTrend &&
    bullishMomentum &&
    rsiOversold &&
    rsiRecovery &&
    volumeConfirmed &&
    notAtTop
  );
}

/**
 * Helper: Get decision explanation
 */
export function explainSignal(indicators, latestCandle) {
  if (!indicators || !latestCandle) {
    return { decision: 'INSUFFICIENT_DATA', explanation: 'Missing indicators or candle data' };
  }

  const {
    rsi,
    ema8,
    ema21,
    bollingerBands,
    volumeSMA,
    close,
  } = indicators;

  const conditions = {
    'Price > EMA21': close > ema21,
    'EMA8 > EMA21': ema8 > ema21,
    'RSI < 40': rsi < 40,
    'RSI > 45': rsi > 45,
    'Volume > MA': latestCandle.v > volumeSMA,
    'Not at BB Upper': close < bollingerBands.upper,
  };

  const conditionText = Object.entries(conditions)
    .map(([name, met]) => `${met ? '✓' : '✗'} ${name}`)
    .join('\n');

  const allMet = Object.values(conditions).every(c => c);
  const decision = allMet ? 'BUY' : 'PASS';

  return {
    decision,
    conditions,
    conditionText,
    explanation: `${decision === 'BUY' ? 'All 6 conditions met - ready to enter' : 'Some conditions not met - waiting'}`,
    values: {
      close,
      ema8,
      ema21,
      rsi,
      volume: latestCandle.v,
      volumeSMA,
    },
  };
}

export default BridgeClient;
