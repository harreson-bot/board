# TradingView Bridge — Deployment Guide

**Status:** Ready to deploy  
**Target:** DreamHost vps48233 (dh_ygjkxx account)  
**Port:** 3001  
**Process Manager:** PM2  

---

## Quick Deployment (Copy & Paste)

```bash
# SSH into DreamHost
ssh dh_ygjkxx@vps48233.dreamhostps.com

# Create directory
mkdir -p /home/dh_ygjkxx/tradingview-bridge
cd /home/dh_ygjkxx/tradingview-bridge

# Clone or copy files (from your machine, in separate terminal):
sshpass -p '#KingBl@ckwell2026#' scp -r \
  /home/harreson/.openclaw/workspace/tradingview-bridge/* \
  dh_ygjkxx@vps48233.dreamhostps.com:/home/dh_ygjkxx/tradingview-bridge/

# Back in DreamHost SSH:
source ~/.nvm/nvm.sh
npm install

# Start with PM2
pm2 start bridge-server.js --name "tv-bridge"
pm2 save
pm2 list

# Verify
curl http://localhost:3001/health
```

---

## Full Deployment Walkthrough

### Step 1: Prepare Files (On Your Machine)

```bash
cd /home/harreson/.openclaw/workspace/tradingview-bridge

# Make sure these exist:
ls -la bridge-server.js bridge-client.js package.json .env.example
```

### Step 2: Upload to DreamHost

Using sshpass (non-interactive password):

```bash
DEST="dh_ygjkxx@vps48233.dreamhostps.com:/home/dh_ygjkxx/tradingview-bridge/"

# Create directory first
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "mkdir -p /home/dh_ygjkxx/tradingview-bridge"

# Copy all files
sshpass -p '#KingBl@ckwell2026#' scp -r \
  bridge-server.js \
  bridge-client.js \
  package.json \
  .env.example \
  BRIDGE_README.md \
  "$DEST"

echo "✓ Files uploaded"
```

### Step 3: Install Dependencies

```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com << 'ENDSSH'
source ~/.nvm/nvm.sh
cd /home/dh_ygjkxx/tradingview-bridge
npm install
echo "✓ Dependencies installed"
ENDSSH
```

### Step 4: Start with PM2

```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com << 'ENDSSH'
source ~/.nvm/nvm.sh
cd /home/dh_ygjkxx/tradingview-bridge
pm2 start bridge-server.js --name "tv-bridge"
pm2 save
echo "✓ Bridge started"
ENDSSH
```

### Step 5: Verify Deployment

```bash
# Check process status
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "source ~/.nvm/nvm.sh && pm2 list"

# Check health endpoint
curl http://localhost:3001/health

# Should return:
# {
#   "status": "ok",
#   "tvConnected": false,
#   "symbols": ["SOLUSDT", "BTCUSDT", "ETHUSDT"],
#   "dataPoints": {"SOLUSDT": 50, "BTCUSDT": 50, "ETHUSDT": 50}
# }
```

---

## All-in-One Bash Script

Save this as `deploy-bridge.sh`:

```bash
#!/bin/bash

REMOTE_USER="dh_ygjkxx"
REMOTE_HOST="vps48233.dreamhostps.com"
REMOTE_PASS="#KingBl@ckwell2026#"
REMOTE_DIR="/home/dh_ygjkxx/tradingview-bridge"

echo "🚀 Deploying TradingView Bridge..."

# 1. Create directory
echo "📁 Creating directory..."
sshpass -p "$REMOTE_PASS" ssh "$REMOTE_USER@$REMOTE_HOST" \
  "mkdir -p $REMOTE_DIR"

# 2. Upload files
echo "📤 Uploading files..."
sshpass -p "$REMOTE_PASS" scp -r \
  bridge-server.js \
  bridge-client.js \
  package.json \
  .env.example \
  BRIDGE_README.md \
  "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR/"

# 3. Install & start
echo "⚙️  Installing dependencies..."
sshpass -p "$REMOTE_PASS" ssh "$REMOTE_USER@$REMOTE_HOST" << 'ENDSSH'
source ~/.nvm/nvm.sh
cd /home/dh_ygjkxx/tradingview-bridge
npm install
pm2 start bridge-server.js --name "tv-bridge"
pm2 save
ENDSSH

# 4. Verify
echo "✅ Deployment complete!"
echo ""
echo "📊 Bridge Status:"
curl -s http://localhost:3001/health | jq .

echo ""
echo "🔗 Available endpoints:"
echo "  Health:     http://localhost:3001/health"
echo "  Candles:    http://localhost:3001/candles/SOLUSDT"
echo "  Indicators: http://localhost:3001/indicators/SOLUSDT"
echo "  Status:     http://localhost:3001/status"
echo "  WebSocket:  ws://localhost:3001"
```

Usage:
```bash
chmod +x deploy-bridge.sh
./deploy-bridge.sh
```

---

## Post-Deployment Verification

### Test REST API

```bash
# 1. Health check
curl http://localhost:3001/health
# Expected: status "ok"

# 2. Get candles
curl http://localhost:3001/candles/SOLUSDT?limit=5
# Expected: array of 5 candles with o, h, l, c, v, t

# 3. Get indicators
curl http://localhost:3001/indicators/SOLUSDT | jq .indicators
# Expected: rsi, ema8, ema21, bollingerBands, volumeSMA, close

# 4. Full status
curl http://localhost:3001/status | jq .bridge
# Expected: running=true, port=3001
```

### Monitor Logs

```bash
# View last 50 lines
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "tail -50 /home/dh_ygjkxx/.pm2/logs/tv-bridge-out.log"

# Watch in real-time
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "tail -f /home/dh_ygjkxx/.pm2/logs/tv-bridge-out.log"
```

---

## Managing the Bridge

### Check Status
```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "source ~/.nvm/nvm.sh && pm2 status"
```

### Stop the Bridge
```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "source ~/.nvm/nvm.sh && pm2 stop tv-bridge"
```

### Restart the Bridge
```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "source ~/.nvm/nvm.sh && pm2 restart tv-bridge"
```

### Delete the Bridge
```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "source ~/.nvm/nvm.sh && pm2 delete tv-bridge"
```

### View Real-Time Logs
```bash
sshpass -p '#KingBl@ckwell2026#' ssh dh_ygjkxx@vps48233.dreamhostps.com \
  "source ~/.nvm/nvm.sh && pm2 logs tv-bridge"
```

---

## Troubleshooting Deployment

### "command not found: node"
→ Add `source ~/.nvm/nvm.sh` before any node/npm commands

### "npm: command not found"
→ Same issue — always run `source ~/.nvm/nvm.sh` first

### Port 3001 already in use
→ Change port in .env or check what's using it:
```bash
lsof -i :3001
```

### Bridge starts but no data
→ Normal — it starts with demo data while waiting for TradingView connection
→ Check `/status` endpoint to see data availability

### WebSocket connection failing
→ Firewall might be blocking outbound WebSocket
→ DreamHost usually allows this, but check with support

---

## Integration with Trading Bot

Once deployed, update your bot to use the bridge:

```javascript
import { BridgeClient } from './bridge-client.js'

const bridge = new BridgeClient('http://localhost:3001')

// In your bot's trade logic:
const indicators = await bridge.getIndicators('SOLUSDT')
const candle = await bridge.getLatestCandle('SOLUSDT')

// Use bridge data for trading decisions
if (indicators.rsi < 40 && indicators.ema8 > indicators.ema21) {
  // Execute trade
}
```

---

## Next: Update SOLANA Bot

The bridge is now running. Next step: update `bot.js` to use it instead of fetching data directly.

See: `../claude-tradingview-mcp-trading/bot.js`

---

**Status:** ✅ Ready to deploy  
**Deployment Time:** ~5 minutes  
**Success Indicator:** `curl http://localhost:3001/health` returns status "ok"
